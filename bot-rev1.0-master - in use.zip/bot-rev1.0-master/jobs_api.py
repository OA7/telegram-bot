import requests
from bs4 import BeautifulSoup
from bot import *

base_url = r'http://stucfb.hunterhrms.com/'


class StudyField:
    """
    A class that represents a field of study, with a unique ID
    """

    def __init__(self, name, id):
        self.name = name
        self.id = id
        self.is_picked = False

    def __repr__(self):
        return f"field: {self.name} value: {self.id} is_picked: {str(self.is_picked)}"


class Location:
    def __init__(self, location, id):
        self.name = location
        self.id = id
        self.is_picked = False

    def __repr__(self):
        return f"location: {self.name}, id: {self.id}"


class JobOffer:
    def __init__(self, title, link):
        self.title = title
        self.link = base_url + link

    def __repr__(self):
        return "title: " + self.title + '\nurl: ' + self.link


def get_jobsite_soup():
    response = requests.get(base_url)
    return BeautifulSoup(response.text, "html.parser")


def get_fields_of_study(soup):
    # get the fields of study
    fields = []
    selection_field = soup.find(id='hunter-search-category')
    options = selection_field.find_all('option')
    for option in options:
        field = StudyField(option.text, option['value'])
        fields.append(field)
    return fields


def get_locations(soup):
    locations = []
    selection_field = soup.find(id='hunter-search-regions')
    options = selection_field.find_all('option')
    for option in options:
        location = Location(option.text, option['value'])
        locations.append(location)
    return locations


def get_jobs(user_data):
    job_offers_list = []
    payload = {'option': 'com_hunter',
               'view': 'searchresults'}
    payload_index = 0
    for field in user_data.fields:
        if field.is_picked:
            payload[f"hunter-search-category[{payload_index}]"] = field.id
            payload_index += 1
    payload_index = 0
    for location in user_data.locations:
        if location.is_picked:
            payload[f"hunter-search-regions[{payload_index}]"] = location.id
            payload_index += 1
    response = requests.get(base_url, params=payload)
    job_list_soup = BeautifulSoup(response.text, 'html.parser')
    jobs = job_list_soup.find_all('p', class_='item-title')
    for job in jobs:
        job_offer = JobOffer(job.a.text, job.a['href'])
        job_offers_list.append(job_offer)
    return job_offers_list
