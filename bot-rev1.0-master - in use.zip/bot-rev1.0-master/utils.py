def extract_id(callback_data):
    return callback_data.split(",")[1:].pop()
