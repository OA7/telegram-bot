from jobs_api import *
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, RegexHandler, MessageHandler, Filters
import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

# =============== constants =========================

UP_ARROWS = "⬆️⬆️⬆️⬆️"
DOWN_ARROWS = "⬇️⬇️⬇️⬇️"

OPEN_MESSAGE = UP_ARROWS*2 + """\

ברוכים הבאים לבוט של Student Jobs!
מוזמנים לשתף לחברים את הקישור הזה:
https://t.me/StudentJobsBot
בחר שדה לימוד מהרשימה ותקבל את המשרות הרלוונטיות.
"""

LOCATIONS_MESSAGE = """\
בחר איזור. ניתן לבחור כמה איזורים במקביל. לאחר בחירת האיזורים לחץ על "חפש".
"""

JOBS_MESSAGE = """\
הנה המשרות שחיפשת:
"""
NO_JOBS = "הפעם לא מצאנו משרה מבוקשת, מוזמנים לבדוק שוב בקרוב שכן כל הזמן נוספות משרות חדשות."
CONTINUE = "continue"
GO_BACK = "back"

GO_BACK_TEXT = "↩️ חזור ↩️"
SEARCH_BUTTON_TEXT = "🔍 חפש 🔍"
NEW_SEARCH = "↩️ חיפוש חדש ↩️"
START = "start"


class ChatData:
    def __init__(self):
        # getting request
        self.soup = get_jobsite_soup()

        # data
        self.fields = get_fields_of_study(self.soup)
        self.locations = get_locations(self.soup)

    def __repr__(self):
        return "in chat data"

    def get_markup(self, alist):
        keyboard = []
        data_name = "field" if alist == self.fields else "location"
        for i, element in enumerate(alist):
            keyboard.append([InlineKeyboardButton("✔ " + element.name
                                                  if element.is_picked
                                                  else element.name,
                                                  callback_data=data_name + "," + element.id)])
        row = []
        if data_name == "location":
            row.append(InlineKeyboardButton(SEARCH_BUTTON_TEXT, callback_data=data_name + "," + CONTINUE))
            # TODO:  delete
            # row.append(InlineKeyboardButton(NEW_SEARCH, callback_data=START))
            row.append(InlineKeyboardButton(NEW_SEARCH, callback_data=data_name + "," + GO_BACK))
            # row.append(InlineKeyboardButton(GO_BACK_TEXT, callback_data=data_name + "," + GO_BACK))
        keyboard.append(row)
        return InlineKeyboardMarkup(keyboard)

    def get_jobs_markup(self):
        jobs = get_jobs(self)
        keyboard = []
        for job in jobs:
            keyboard.append([InlineKeyboardButton(job.title, url=job.link)])
        keyboard.append([InlineKeyboardButton(NEW_SEARCH, callback_data=START)])
        return InlineKeyboardMarkup(keyboard)

    def pick_field(self, field_id):
        for field in self.fields:
            if field.id == field_id:
                field.is_picked = not field.is_picked

    def pick_location(self, location_id):
        for location in self.locations:
            if location.id == location_id:
                location.is_picked = not location.is_picked

    @staticmethod
    def reset_picked(alist):
        for item in alist:
            if isinstance(item, StudyField) or isinstance(item, Location):
                item.is_picked = False


# bot token
TOKEN = r'722154526:AAGxy5nrD_t2WAcPi5Tbv1HNGHCBja6MPXs'


def start(update, context):
    context.chat_data['data'] = ChatData()
    data = context.chat_data['data']
    message = update.message if update.message else update.callback_query.message
    context.bot.send_message(chat_id=message.chat.id, text=DOWN_ARROWS,
                             reply_markup=data.get_markup(data.fields),
                             disable_web_page_preview=True)
    # context.bot.send_message(chat_id=message.chat.id, text=UP_ARROWS)
    follow_up_message = context.bot.send_message(chat_id=message.chat.id, text=OPEN_MESSAGE,
                             disable_web_page_preview=True)
    context.chat_data['last_message'] = follow_up_message


def fields_callback(update, context):
    try:
        data = context.chat_data['data']
    except KeyError:
        context.chat_data['data'] = ChatData()
        data = context.chat_data['data']

    callback_data = update.callback_query.data.split(",")[1]
    # reset all picked and pick the new field
    data.reset_picked(data.fields)
    data.pick_field(callback_data)
    # delete the follow up message
    context.chat_data['last_message'].delete()
    update.callback_query.message.edit_text(LOCATIONS_MESSAGE, reply_markup=data.get_markup(data.locations))


def locations_callback(update, context):
    update.callback_query.answer()  # remove the loading circle in the corner
    try:
        data = context.chat_data['data']
        callback_data = update.callback_query.data.split(",")[1]
        if callback_data == CONTINUE:
            # make the search
            markup = data.get_jobs_markup()
            message = JOBS_MESSAGE if len(markup.inline_keyboard) > 1 else NO_JOBS
            update.callback_query.message.edit_text(message, reply_markup=markup)
        elif callback_data == GO_BACK:  # go back to fields
            # delete current message
            update.callback_query.message.delete()
            # start again
            start(update, context)
            # data.reset_picked(data.fields)
            # update.callback_query.message.edit_reply_markup(reply_markup=data.get_markup(data.fields))
        else:
            data.pick_location(callback_data)
            update.callback_query.message.edit_reply_markup(reply_markup=data.get_markup(data.locations))
    except KeyError:
        # if there is no chat data, delete the message and start again
        context.bot.delete_message(chat_id=update.callback_query.message.chat.id,
                                   message_id=update.callback_query.message.message_id)
        start(update, context)


if __name__ == "__main__":
    updater = Updater(token=TOKEN, use_context=True)
    dispatcher = updater.dispatcher
    logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                        level=logging.INFO)

    # add handlers
    dispatcher.add_handler(CommandHandler('start', start))
    dispatcher.add_handler(MessageHandler(Filters.regex('(start)'), start))
    updater.dispatcher.add_handler(CallbackQueryHandler(callback=fields_callback, pattern=r'^field'))
    updater.dispatcher.add_handler(CallbackQueryHandler(callback=locations_callback, pattern=r'^location'))
    updater.dispatcher.add_handler(CallbackQueryHandler(callback=start, pattern=START))
    print("bot started")

    updater.start_polling()
